// utils/restart.js
import fs from "fs";
import { spawn } from "child_process";
import { fileURLToPath } from "url";
import path from "path";

export function restartAgent() {
  try {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    const entryScript = path.join(__dirname, "../index.js");

    // 🏁 Buat penanda agar tahu restart sedang berjalan
    const flagPath = path.join(__dirname, "../.restarting");
    fs.writeFileSync(flagPath, "restart-triggered");

    const child = spawn(process.execPath, [entryScript], {
      detached: true,
      stdio: "ignore", // → jika ingin lihat log, ubah jadi 'inherit'
    });

    child.unref(); // biarkan berjalan mandiri
    process.exit(0); // keluar dari proses lama
  } catch (err) {
    console.error("❌ Restart agent gagal:", err);
  }
}
