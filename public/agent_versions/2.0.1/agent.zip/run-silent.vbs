Set fso = CreateObject("Scripting.FileSystemObject")
Set WshShell = CreateObject("WScript.Shell")
exePath = fso.GetParentFolderName(WScript.ScriptFullName) & "\smart-monitoring-agent.exe"
WshShell.Run Chr(34) & exePath & Chr(34), 0
Set WshShell = Nothing
