import fs from "fs/promises";
import path from "path";
import dayjs from "dayjs";

const UPTIME_FILE = path.join(process.cwd(), "data", "uptime.json");
let sessionUptime = 0;
let intervalId = null;
let lastSessionStart = Date.now();

async function readUptimeData() {
  try {
    const content = await fs.readFile(UPTIME_FILE, "utf-8");
    return JSON.parse(content);
  } catch {
    return {};
  }
}

async function writeUptimeData(data) {
  await fs.mkdir(path.dirname(UPTIME_FILE), { recursive: true });
  await fs.writeFile(UPTIME_FILE, JSON.stringify(data, null, 2));
}

async function emitUptime(socket, config, session, total) {
  socket.emit("uptime", {
    pc: config.pcId,
    date: dayjs().format("YYYY-MM-DD"),
    uptimeSession: session,
    uptimeTotalToday: total,
  });

  console.log(
    `🕓 Uptime Emit | Session: ${Math.floor(
      session
    )}s, Total Today: ${Math.floor(total)}s`
  );
}

export async function emitAtStartup(socket, config) {
  const today = dayjs().format("YYYY-MM-DD");
  try {
    const data = await readUptimeData();
    const totalToday = data[today] || 0;
    sessionUptime = 0;
    lastSessionStart = Date.now();
    await emitUptime(socket, config, sessionUptime, totalToday);
  } catch (err) {
    console.error("❌ Gagal emit uptime saat startup:", err.message);
  }
}

export function startUptimeService(socket, config, interval = 60) {
  if (intervalId) clearInterval(intervalId);

  sessionUptime = 0;
  lastSessionStart = Date.now();

  intervalId = setInterval(async () => {
    const now = Date.now();
    const duration = Math.floor((now - lastSessionStart) / 1000); // detik
    sessionUptime += duration;
    lastSessionStart = now;

    const today = dayjs().format("YYYY-MM-DD");

    try {
      const data = await readUptimeData();
      data[today] = (data[today] || 0) + duration;
      await writeUptimeData(data);

      await emitUptime(socket, config, sessionUptime, data[today]);
    } catch (err) {
      console.error("❌ Gagal update uptime:", err.message);
    }
  }, interval * 1000);
}

export function stopUptimeService() {
  if (intervalId) clearInterval(intervalId);
  intervalId = null;
  console.log("🛑 Uptime Service Stopped");
}
