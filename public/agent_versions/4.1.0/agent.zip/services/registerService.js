// 📁 services/registerService.js
import si from "systeminformation";
import axios from "axios";
import { API_BASE_URL } from "../utils/env.js";
import { loadConfig, saveConfig } from "../utils/configHandler.js";

export async function loadOrRegisterPc() {
  let config = await loadConfig();

  if (config && config.pcId) {
    console.log("✅ pcId ditemukan:", config.pcId);
    return config.pcId;
  }

  console.warn("⚠️ config.json tidak ditemukan atau belum lengkap.");
  console.warn("⚠️ Belum ada config, mulai proses registrasi...");

  // Ambil data hardware
  const system = await si.system();
  const cpuInfo = await si.cpu();
  const chassis = await si.chassis();
  const mem = await si.mem();
  const osInfo = await si.osInfo();

  let user = "unknown";
  try {
    user = process.env.USERNAME || process.env.USER || "unknown";
  } catch {
    console.warn("⚠️ Gagal ambil user info");
  }

  const isLaptop =
    chassis.type?.toLowerCase().includes("laptop") ||
    system.model?.toLowerCase().includes("laptop");
  const type = isLaptop ? "LT" : "DT";
  const isAdmin = /admin|it|support/i.test(user.toLowerCase());

  const serialNumber = system.serial || system.uuid || "UNKNOWN";
  const cpu = cpuInfo.brand || "UNKNOWN";
  const ram = `${(mem.total / 1024 / 1024 / 1024).toFixed(0)} GB`;
  const os = `${osInfo.distro} ${osInfo.arch}`;

  const payload = {
    serialNumber,
    assetNumber: "-",
    pic: "-",
    userLogin: user,
    isAdmin,
    type,
    cpu,
    ram,
    os,
  };

  console.log("📦 Data dikirim ke backend:", payload);

  try {
    const res = await axios.post(`${API_BASE_URL}/api/pc/register`, payload);

    const {
      pcId: objectId, // gunakan _id Mongo
      isAdmin: backendIsAdmin,
      type: backendType,
      userLogin: backendUserLogin,
    } = res.data;

    const newConfig = {
      pcId: objectId, // simpan sebagai pcId
      version: "1.0.0",
      userLogin: backendUserLogin ?? user,
      isAdmin: backendIsAdmin ?? isAdmin,
      type: backendType ?? type,
      registeredAt: new Date().toISOString(),
    };

    await saveConfig(newConfig);
    console.log(
      "✅ pcId (ObjectId) disimpan dan konfigurasi disinkronkan:",
      objectId
    );
    return objectId;
  } catch (err) {
    console.error("❌ Gagal register PC ke backend:", err.message);
    throw new Error("Gagal registrasi PC. Cek koneksi atau server backend.");
  }
}
