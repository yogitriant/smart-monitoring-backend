// services/statusService.js
import os from "os";
import si from "systeminformation";
import { getIdleTime } from "../utils/getIdleTime.js";

export default function startStatusService(socket, config) {
  const INTERVAL = 5000; // kirim status setiap 5 detik

  let lastStatus = null;

  const emitStatus = async () => {
    const idleTime = await getIdleTime();
    const isIdle = idleTime > config.idleTimeout * 60 * 1000; // idleTimeout dalam menit

    const status = isIdle ? "idle" : "online";

    // Jika status berubah, baru kirim
    if (status !== lastStatus) {
      socket.emit("status", {
        pcId: config.pcId,
        status,
        timestamp: new Date().toISOString(),
      });
      lastStatus = status;
    }
  };

  emitStatus();
  setInterval(emitStatus, INTERVAL);
}
