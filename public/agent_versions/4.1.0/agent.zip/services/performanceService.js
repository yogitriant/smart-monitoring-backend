import os from "os";
import si from "systeminformation";
import { getIdleTime as getIdleTimeRaw } from "../utils/getIdleTime.js";
import { getUptimeTotalToday } from "../utils/uptimeHelper.js";
import { setIdleTime } from "../utils/sharedState.js";

const agentStartTime = Date.now();

function formatTime(sec) {
  const h = Math.floor(sec / 3600);
  const m = Math.floor((sec % 3600) / 60);
  const s = Math.floor(sec % 60);
  return `${String(h).padStart(2, "0")}:${String(m).padStart(2, "0")}:${String(
    s
  ).padStart(2, "0")}`;
}

export default function startPerformanceService(socket, config) {
  setInterval(async () => {
    try {
      const [cpu, mem, disks] = await Promise.all([
        si.currentLoad(),
        si.mem(),
        si.fsSize(),
      ]);

      // ✅ Ambil idle dari PowerShell → simpan ke sharedState
      const idleTime = await getIdleTimeRaw();
      setIdleTime(idleTime);

      const uptime = os.uptime();
      const agentUptime = Math.floor((Date.now() - agentStartTime) / 1000);
      const uptimeTotal = await getUptimeTotalToday();

      const cpuUsage = Math.round(cpu.currentLoad);
      const ramUsage = Math.round((mem.active / mem.total) * 100);
      const diskUsage = disks.map((d) => ({
        drive: d.mount,
        used: +(d.used / 1024 / 1024 / 1024).toFixed(2),
        total: +(d.size / 1024 / 1024 / 1024).toFixed(2),
      }));

      // Kirim ke backend via socket
      socket.emit("performance", {
        pc: config.pcId,
        cpuUsage,
        ramUsage,
        diskUsage,
        idleTime,
        uptime,
        agentUptime,
        uptimeTotal,
        timestamp: new Date(),
      });

      // Logging lokal
      console.log(
        `📊 Performance | CPU: ${cpuUsage}%, RAM: ${ramUsage}%, Boot: ${formatTime(
          uptime
        )}, Agent: ${formatTime(agentUptime)}, Total: ${formatTime(
          uptimeTotal
        )}, Idle: ${idleTime}s`
      );
    } catch (err) {
      console.error("❌ Gagal ambil data performa:", err.message);
    }
  }, 10_000); // 10 detik interval
}
