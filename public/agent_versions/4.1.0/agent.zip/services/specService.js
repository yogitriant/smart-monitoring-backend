import si from "systeminformation";
import { sendData } from "../utils/socketHelper.js";
import { getStoredSpec, saveStoredSpec } from "../utils/specStorage.js";

export default async function startSpecService(socket, config, force = false) {
  try {
    const spec = await collectSpec();
    const lastSpec = await getStoredSpec();

    const isDifferent =
      force || JSON.stringify(spec) !== JSON.stringify(lastSpec);

    if (isDifferent) {
      console.log("📡 Kirim spec agent:", {
        pcId: config.pcId,
        ...spec,
      });

      sendData(socket, "spec", { pcId: config.pcId, ...spec });
      await saveStoredSpec(spec);
      console.log("🖥️ Spesifikasi dikirim dan disimpan.");
    } else {
      console.log("🖥️ Spesifikasi tidak berubah, tidak dikirim.");
    }
  } catch (err) {
    console.error("❌ Gagal ambil/kirim spesifikasi:", err.message);
  }
}

async function collectSpec() {
  const cpu = await si.cpu();
  const mem = await si.mem();
  const os = await si.osInfo();
  const disk = await si.diskLayout();
  const bios = await si.bios();
  const gpu = await si.graphics();
  const net = await si.networkInterfaces();
  const baseboard = await si.baseboard();
  const resolution = await si.graphics();

  return {
    brand: baseboard.manufacturer || bios.vendor || "-",
    model: baseboard.model || "-",
    cpu: `${cpu.manufacturer} ${cpu.brand}`,
    ram: `${Math.round(mem.total / 1024 / 1024 / 1024)} GB`,
    os: `${os.distro} ${os.arch}`,
    gpu: gpu.controllers.map((g) => g.model).join(", "),
    macAddress: net[0]?.mac || "-",
    ipAddress: net[0]?.ip4 || "-",
    resolution:
      resolution.displays[0]?.currentResX && resolution.displays[0]?.currentResY
        ? `${resolution.displays[0].currentResX}x${resolution.displays[0].currentResY}`
        : "-",
    disk: disk.map((d, i) => ({
      drive: String.fromCharCode(67 + i), // C, D, E
      type: d.type || "SSD",
      total: `${(d.size / 1024 / 1024 / 1024).toFixed(0)} GB`,
    })),
    bios: bios.vendor,
  };
}
