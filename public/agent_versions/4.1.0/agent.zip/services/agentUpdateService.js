// services/agentUpdateService.js
import fs from "fs";
import path from "path";
import fetch from "node-fetch";
import unzipper from "unzipper";
import { exec } from "child_process";
import { loadConfig, saveConfig } from "../utils/configHandler.js";
import { logUpdate } from "../utils/logger.js";
import { restartAgent } from "../utils/restart.js";

export async function handleAgentUpdate(data, socket) {
  const { pcId, version, silent = true, force = false } = data;
  const zipUrl = `${process.env.API_BASE_URL}/agent_versions/${version}/agent.zip`;

  const config = await loadConfig();
  const currentVersion = config.version || "unknown";

  // Skip update jika versi sama dan tidak force
  if (version === currentVersion && !force) {
    logUpdate(`⚠️ Skip update: version ${version} is already current.`);
    return;
  }

  try {
    const agentDir = process.cwd(); // contoh: C:/SmartAgent/current
    const baseDir = path.resolve(agentDir, ".."); // keluar dari current
    const backupDir = path.resolve(baseDir, "backup", currentVersion);
    const tempZipPath = path.resolve(baseDir, "tmp_update.zip");

    // 1. Backup folder lama ke luar folder agent
    fs.mkdirSync(backupDir, { recursive: true });
    fs.cpSync(agentDir, backupDir, {
      recursive: true,
      filter: (src) => {
        const relative = path.relative(agentDir, src);
        return (
          !relative.startsWith("backup") && !relative.startsWith("node_modules")
        );
      },
    });

    // 2. Download ZIP
    const res = await fetch(zipUrl);
    if (!res.ok) throw new Error(`Gagal download zip: ${res.statusText}`);

    const fileStream = fs.createWriteStream(tempZipPath);
    await new Promise((resolve, reject) => {
      res.body.pipe(fileStream);
      res.body.on("error", reject);
      fileStream.on("finish", resolve);
    });

    // 3. Ekstrak ZIP ke agentDir
    await fs
      .createReadStream(tempZipPath)
      .pipe(unzipper.Extract({ path: agentDir }))
      .promise();

    // 4. npm install
    await new Promise((resolve, reject) => {
      exec("npm install", { cwd: agentDir }, (err, stdout, stderr) => {
        if (err) reject(stderr);
        else resolve(stdout);
      });
    });

    // 5. Simpan config baru
    config.version = version;
    config.lastUpdate = new Date().toISOString();
    await saveConfig(config);

    // 6. Kirim hasil ke backend
    socket.emit("agent-update-result", {
      pcId,
      version,
      status: "success",
      message: "Update berhasil",
    });

    logUpdate(`✅ Update ke ${version} berhasil.`);

    // 7. Restart agent setelah delay
    setTimeout(() => {
      restartAgent();
    }, 1500);
  } catch (err) {
    logUpdate(`❌ Gagal update ke ${version}: ${err.message}`);
    socket.emit("agent-update-result", {
      pcId,
      version,
      status: "failed",
      message: err.message,
    });
  }
}
