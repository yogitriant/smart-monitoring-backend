import { getIdleTime } from "../utils/sharedState.js";
import { exec } from "child_process";

let intervalId = null;
let shutdownIssued = false;

export function startAutoShutdownService(socket, config) {
  if (intervalId) clearInterval(intervalId);

  // ✅ Konversi dari menit ke detik
  const idleTimeout = Number(config.idleTimeout) * 60;

  if (idleTimeout <= 0) {
    console.log("⛔ Auto Shutdown dinonaktifkan (idleTimeout <= 0)");
    return;
  }

  const shutdownDelay = Number(config.shutdownDelay) * 60;

  console.log("💤 [autoShutdownService] Monitoring idle...");
  console.log(
    `⌛ Idle timeout: ${idleTimeout} detik (${idleTimeout / 60} menit)`
  );
  console.log(
    `⚠️ Shutdown delay: ${shutdownDelay} detik (${shutdownDelay / 60} menit)`
  );

  intervalId = setInterval(() => {
    const idleTime = getIdleTime();
    console.log("⌛ Idle time:", idleTime, "| Timeout:", idleTimeout);

    if (idleTime >= idleTimeout && !shutdownIssued) {
      console.log("⚠️ Idle terlalu lama! Persiapan shutdown...");
      exec(
        `msg * Komputer akan dimatikan dalam ${shutdownDelay} detik karena tidak aktif`
      );
      exec(`shutdown /s /t ${shutdownDelay}`);
      shutdownIssued = true;
    }

    // Jika user aktif kembali sebelum shutdown dieksekusi
    if (shutdownIssued && idleTime < 10) {
      console.log("✅ Aktivitas terdeteksi ulang, shutdown dibatalkan.");
      exec("shutdown /a");
      shutdownIssued = false;
    }
  }, 10_000); // Cek setiap 10 detik
}

export function stopAutoShutdownService() {
  if (intervalId) clearInterval(intervalId);
  exec("shutdown /a"); // Antisipasi shutdown tertunda
  shutdownIssued = false;
  console.log("🛑 Auto Shutdown Service Stopped");
}
