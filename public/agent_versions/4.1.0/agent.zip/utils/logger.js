import fs from "fs";
import path from "path";

const logFilePath = path.resolve("logs", "update.log");

export function logUpdate(message) {
  const timestamp = new Date().toISOString();
  const fullMessage = `[${timestamp}] ${message}\n`;

  // Pastikan folder logs/ ada
  const dir = path.dirname(logFilePath);
  if (!fs.existsSync(dir)) {
    fs.mkdirSync(dir, { recursive: true });
  }

  fs.appendFileSync(logFilePath, fullMessage, "utf-8");
}
