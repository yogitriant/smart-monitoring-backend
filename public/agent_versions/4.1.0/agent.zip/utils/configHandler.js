// 📁 utils/configHandler.js
import fs from "fs";
import path from "path";

const CONFIG_PATH = path.resolve("config.json");

export const loadConfig = async () => {
  try {
    if (!fs.existsSync(CONFIG_PATH)) {
      console.log("⚠️ config.json tidak ditemukan.");
      return null;
    }

    const raw = fs.readFileSync(CONFIG_PATH, "utf-8");
    return JSON.parse(raw);
  } catch (err) {
    console.error("❌ Gagal load config:", err.message);
    return null;
  }
};

export const saveConfig = async (config) => {
  try {
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(config, null, 2));
    console.log("💾 Config disimpan:", config);
  } catch (err) {
    console.error("❌ Gagal simpan config:", err.message);
  }
};
