import fs from "fs/promises";
import path from "path";
import dayjs from "dayjs";

const UPTIME_FILE = path.join(process.cwd(), "data", "uptime.json");

export async function getUptimeTotalToday() {
  const today = dayjs().format("YYYY-MM-DD");

  try {
    const content = await fs.readFile(UPTIME_FILE, "utf-8");
    const data = JSON.parse(content);
    return data[today] || 0;
  } catch {
    return 0;
  }
}
