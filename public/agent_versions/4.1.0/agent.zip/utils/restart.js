import { spawn } from "child_process";
import { fileURLToPath } from "url";
import path from "path";
import fs from "fs";

export function restartAgent() {
  try {
    const __filename = fileURLToPath(import.meta.url);
    const __dirname = path.dirname(__filename);
    const entryScript = path.join(__dirname, "../index.js");

    const flagPath = path.join(__dirname, "../.restarting");
    fs.writeFileSync(flagPath, "restart-triggered");

    // ✅ Gunakan format string literal tanpa kutip dua ekstra
    const cmd = `node ${entryScript}`;
    spawn("cmd.exe", ["/c", "start", "cmd.exe", "/k", cmd], {
      detached: true,
      stdio: "ignore",
    }).unref();

    process.exit(0);
  } catch (err) {
    console.error("❌ Restart agent gagal:", err);
  }
}
