let idleTime = 0;

export function setIdleTime(value) {
  idleTime = value;
}

export function getIdleTime() {
  return idleTime;
}
