// utils/specStorage.js
import os from "os";
import fs from "fs";
import path from "path";

const specPath = path.join(os.homedir(), ".smart-agent-spec.json");

export function getStoredSpec() {
  try {
    if (!fs.existsSync(specPath)) return null;
    return JSON.parse(fs.readFileSync(specPath, "utf-8"));
  } catch {
    return null;
  }
}

export function saveStoredSpec(spec) {
  try {
    fs.writeFileSync(specPath, JSON.stringify(spec, null, 2));
  } catch (err) {
    console.error("❌ Gagal simpan spesifikasi lokal:", err.message);
  }
}
