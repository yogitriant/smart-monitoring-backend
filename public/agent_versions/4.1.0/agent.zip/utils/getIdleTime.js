import { promisify } from "util";
import { exec } from "child_process";
const execAsync = promisify(exec);
import path from "path";

export async function getIdleTime() {
  try {
    const scriptPath = path.resolve("scripts/getIdleTime.ps1");
    const { stdout } = await execAsync(
      `powershell -ExecutionPolicy Bypass -File "${scriptPath}"`
    );
    const idle = parseInt(stdout.trim(), 10);

    // Validasi agar tidak out of range
    if (isNaN(idle) || idle < 0 || idle > 86400 * 7) return 0;
    return idle; // dalam detik
  } catch (err) {
    console.error("❌ getIdleTime error:", err.message);
    return 0;
  }
}
