// index.js
import fs from "fs";
import path from "path";

// 🧹 Cek dan hapus file flag `.restarting` jika ada
const restartingFlagPath = path.resolve(".restarting");
if (fs.existsSync(restartingFlagPath)) {
  console.log("🔁 Restart selesai, membersihkan flag...");
  fs.unlinkSync(restartingFlagPath);
}

// ✅ Setelah ini baru mulai logic utama
import { loadConfig, saveConfig } from "./utils/configHandler.js";
import connectSocket from "./socketClient.js";

import { loadOrRegisterPc } from "./services/registerService.js";
import startStatusService from "./services/statusService.js";
import startSpecService from "./services/specService.js";
import startPerformanceService from "./services/performanceService.js";
import {
  startAutoShutdownService,
  stopAutoShutdownService,
} from "./services/autoShutdownService.js";
import {
  startUptimeService,
  stopUptimeService,
  emitAtStartup,
} from "./services/uptimeService.js";
import { API_BASE_URL } from "./utils/env.js";

const main = async () => {
  let config = await loadConfig();

  if (!config || !config.pcId) {
    await loadOrRegisterPc();
    config = await loadConfig();
  }

  const socket = await connectSocket(config.pcId);

  let latest = {};
  try {
    const res = await fetch(
      `${API_BASE_URL}/api/settings/agent-config/${config.pcId}`
    );
    latest = await res.json();
    console.log("📥 Config from backend loaded:", latest);
  } catch (err) {
    console.error("❌ Gagal fetch config saat startup:", err.message);
  }

  // ✅ Jalankan semua service
  startStatusService(socket, config);
  startSpecService(socket, config, true);
  startPerformanceService(socket, config);
  startAutoShutdownService(socket, latest);
  await emitAtStartup(socket, config);
  startUptimeService(socket, config);

  // 🔄 Jika config backend diperbarui, restart beberapa service
  socket.on("agent-config-updated", async () => {
    console.log("🔁 Agent config update detected");

    try {
      const res = await fetch(
        `${API_BASE_URL}/api/settings/agent-config/${config.pcId}`
      );
      const updated = await res.json();

      stopAutoShutdownService();
      stopUptimeService();

      console.log("🚀 Memulai ulang service Auto Shutdown & Uptime...");
      startAutoShutdownService(socket, config, updated.idleTimeout);
      startUptimeService(socket, config, updated.uptimeInterval);

      console.log("✅ Agent services restarted with new config");
    } catch (err) {
      console.error("❌ Gagal fetch config update:", err.message);
    }
  });
};

main();
